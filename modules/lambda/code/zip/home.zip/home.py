


def lambda_handler(event, context):

  name = event['name'] if 'name' in event else ''

  return {
    'statusCode': 200,
    'message': 'hello {}'.format(name)
  }